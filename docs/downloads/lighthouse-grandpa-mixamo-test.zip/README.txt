Lighthouse Grandpa Original GLB for Mixamo
Source: Sadkikyo0930/little-racing-v2
Path: docs/assets/lighthouse-grandpa-Bfj9bp4N.glb
Git blob SHA: 310edbaabb68a2c4fcca5cc263974ab629c077e5
Size: 541804 bytes.
This GLB is copied unchanged. No rig or animation applied.
For Mixamo use Blender to inspect and export FBX.
Test upload, auto-rig, walk and wave on a copy.
Do not overwrite the production GLB or deploy the test.
